const cloudinary = require('cloudinary');

cloudinary.config({
  cloud_name : 'bookbug123',
  api_key : '898452586219825',
  api_secret : 'N8GtbSjheEOe2JVY2W9efflAo3w'
})
